# tests/test_failing_feedback.py

def test_failing_with_feedback():
    assert 1 + 1 == 3, "This test is expected to fail"
